<!-- header area start -->
<?php 
  $pos=[1,4];
          $langid = Session::get('locale') ?? app()->getLocale();

            $res= get_menu($langid,$pos,0) ; $i=1; 
            $pageurl = clean_single_input(request()->segment(2));
?>
<section class="header-top">
    <div class="container">
      <div class="skip-wrper">
        <div title="<?php echo get_commontitle('skip-to-main-content',$langid)->title ?? ''; ?>" class="skip"> <?php echo get_commontitle('skip-to-main-content',$langid)->title ?? ''; ?></div>
        <div class="txt">Text  A-   A   A+</div>
       
      </div>
    </div>
  </section>
  <section class="logo-bar">
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-md-4 logo"><img src="<?php echo e(asset('public/frontend/img/logo.png')); ?>" class="img-fluid" alt=""></div>
        <div class="col-xs-12 col-md-4">
          <div class="logo-m"><img src="<?php echo e(asset('public/frontend/img/logo-02.png')); ?>" class="img-fluid" alt=""></div>
        </div>
        <div class="col-xs-12 col-md-4 logo-barbtn">
          <div class="logo-middle">
            <button type="button" class="btn rm"> <span><img src="<?php echo e(asset('public/frontend/img/module.png')); ?>" alt="<?php echo get_commontitle('restricted-module',$langid)->title ?? ''; ?>"></span>  <?php echo get_commontitle('restricted-module',$langid)->title ?? ''; ?></button>
            <div class="dropdown">
              <button class="btn English dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span><img src="<?php echo e(asset('public/frontend/img/lang.png')); ?>" alt=""></span>  <?php echo get_commontitle('language',$langid)->title ?? ''; ?>
                <span class="arrow"><img src="<?php echo e(asset('public/frontend/img/dropdown-ar.png')); ?>" alt=""></span>
              </button>
              <form id="lang-form">
                <?php echo csrf_field(); ?>
                <div id="lang-select" class="dropdown-menu">
                <?php
                        $language = get_language();
                        foreach($language as $value) {
                        ?>
                    <a class="dropdown-item" href="#" onclick="changeLanguage('<?php echo e($value->lang_code); ?>')"><?php echo e($value->name); ?> </a>
                    <?php } ?>
                </div>
            </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="menubar-wrapper">
    <div class="container">
      <div class="menu-inner">
        <nav class="navbar navbar-expand-lg">
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-togglericons"></span>
            <span class="navbar-togglericons"></span>
            <span class="navbar-togglericons"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
              <li class="nav-item <?php echo e(Route::is('/') ? 'active' : ''); ?>">
                <a class="nav-link no-dot" href="<?php echo e(url('/')); ?>"><i class="fa fa-home" aria-hidden="true"></i> <span class="sr-only">(current)</span></a>
              </li>
            
          
            <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item <?php echo e(Route::is('pages.*') && request()->is('pages/' . $mod->menu_url) ? 'active' : ''); ?> 
              <?php if(has_child($mod->id, $mod->language_id) > 0): ?> dropdown <?php endif; ?>">
        <!-- <a class="nav-link" href="<?php echo e($mod->menu_url); ?>"><?php echo e($mod->menu_name); ?> </a> -->
                <?php if($mod->menu_type==2): ?>
                    <a class="nav-link"  target="_blank" title="<?php echo e($mod->menu_name); ?>"  href="<?php echo e(URL::asset('public/uploads/admin/cmsfiles/menus/')); ?>/<?php echo e($mod->doc_upload); ?>"   > <span><?php echo e($mod->menu_name); ?> </span></a>
                <?php elseif($mod->menu_type==3): ?>
                   <a class="nav-link"  target="_blank" title="<?php echo e($mod->menu_name); ?>"  href="<?php echo e($mod->menu_links); ?>"  > <span><?php echo e($mod->menu_name); ?> </span></a>
            
                <?php else: ?>
                    <?php if(has_child($mod->id, $mod->language_id) > 0): ?>
                       <a class="nav-link  dropdown-toggle" id="navbarDropdown" title="<?php echo e($mod->menu_name); ?>"   role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#"> <span><?php echo e($mod->menu_name); ?> </span></a>
                    <?php else: ?>
                        <a class="nav-link"  title="<?php echo e($mod->menu_name); ?>"  href="<?php if($mod->menu_url=='#'): ?>''<?php else: ?><?php echo e(url('/pages')); ?>/<?php echo e($mod->menu_url); ?><?php endif; ?>"  > <span><?php echo e($mod->menu_name); ?> </span></a>
                    <?php endif; ?>
                <?php endif; ?>
                 <?php if(has_child($mod->id, $mod->language_id) > 0): ?>
                 <?php $ress= get_menu($mod->language_id,$pos,$mod->id); ?> 
                 <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <?php $__currentLoopData = $ress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <?php if($mods->menu_type==2): ?>
                            <a class="dropdown-item"  title="<?php echo e($mods->menu_name); ?>" target="_blank" href="<?php echo e(URL::asset('/public/uploads/admin/cmsfiles/menus/')); ?>/<?php echo e($mods->doc_upload); ?>"  > <span><?php echo e($mods->menu_name); ?> </span></a>
                            <?php elseif($mods->menu_type==3): ?>
                            <a class="dropdown-item"  title="<?php echo e($mods->menu_name); ?>" target="_blank" href="<?php echo e($mods->menu_links); ?>"  > <span><?php echo e($mods->menu_name); ?> </span></a>
                        
                            <?php else: ?>
                            <a class="dropdown-item" title="<?php echo e($mods->menu_name); ?>"  href="<?php if($mods->menu_url=='#'): ?>''<?php else: ?><?php echo e(url('/pages')); ?>/<?php echo e($mods->menu_url); ?><?php endif; ?>"  > <span><?php echo e($mods->menu_name); ?> </span></a>
                            <?php endif; ?>
                     
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                 <?php endif; ?>
              </li>
              <?php $i++  ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
          </div>
        </nav>
      </div>
    </div>
  </section>
<!-- header area end -->

<script>
  
   function changeLanguage(lang) {
      if(lang=='hi'){
       
        if (!confirm("क्या आप निश्चित हैं कि आपने भाषा बदल दी है?")) {
            return; // If the user cancels, do nothing
        }
      }else{

        if (!confirm("Are you sure you changed the language?")) {
            return; // If the user cancels, do nothing
        }
      }
         
        var token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        var url = "<?php echo e(url('/change-language')); ?>";
        
        fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': token,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ lang: lang })
        })
        .then(response => response.json())
        .then(data => {
            // Handle response if needed
            if (data.success) {
               location.reload(); // Reload the page or update content dynamically
            } else {
                console.error('Error:', data.message);
            }
        })
        .catch(error => console.error('Error:', error));
    }
</script>
<?php /**PATH C:\Users\Admin\Documents\GitHub\BCAS\resources\views/frontend/layouts/partials/header.blade.php ENDPATH**/ ?>
<link rel="shortcut icon" type="image/png" href="<?php echo e(asset('public/admin/assets/images/icon/favicon.ico')); ?>">

  <!-- Favicons -->
  <link href="<?php echo e(asset('public/frontend/img/favicon.png')); ?>" rel="icon">
  <link href="<?php echo e(asset('public/frontend/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">
  <!-- Google Fonts -->
  <link
    href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
    rel="stylesheet">
  <!-- Vendor CSS Files -->
  
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('public/frontend/css/owl.carousel.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('public/frontend/css/owl.theme.default.min')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('public/frontend/css/font-awesome.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('public/frontend/css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('public/frontend/css/responsive.css')); ?>" rel="stylesheet"><?php /**PATH C:\Users\Admin\Documents\GitHub\BCAS\resources\views/frontend/layouts/partials/styles.blade.php ENDPATH**/ ?>
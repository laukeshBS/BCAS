<link rel="shortcut icon" type="image/png" href="<?php echo e(asset('public/admin/assets/images/icon/favicon.ico')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/css/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/css/themify-icons.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/css/metisMenu.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/css/slicknav.min.css')); ?>">
<!-- amchart css -->
<link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
<!-- others css -->
<link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/css/typography.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/css/default-css.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/css/styles.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/css/responsive.css')); ?>">
<!-- modernizr css -->
<script src="<?php echo e(asset('public/admin/assets/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(URL::asset('/public/admin/assets/summernote/summernote-bs4.css')); ?>">
<?php /**PATH C:\Users\Admin\Documents\GitHub\BCAS\resources\views/admin/layouts/partials/styles.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification</title>
</head>
<body>
    <h1>Hello {{ $name }},</h1>
    <p><strong>{{ $otp }}</strong> is your SMS OTP for reset of your password. </p>
    <p>This is valid for 5 minutes. Do not share your OTP with anyone. If not requested by you, please contact us or visit (https://bcasindia.gov.in/#!/hi_home) to block your account.</p>
    <br>
    <br>
    <p>Best regards,</p>
    <p>Team BCAS</p>
    
</body>
</html>
import { Component } from '@angular/core';

@Component({
  selector: 'app-super-admin-header',
  standalone: true,
  imports: [],
  templateUrl: './super-admin-header.component.html',
  styleUrl: './super-admin-header.component.css'
})
export class SuperAdminHeaderComponent {

}

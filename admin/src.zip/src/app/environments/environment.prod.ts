export const environment = {

  //apiBaseUrl: 'http://206.1.13.193:6002/bcas/api/',
  // apiDocBaseUrl: 'http://206.1.13.193:6002/bcas/',

  apiBaseUrl: 'http://127.0.0.1:8000/api/',
  apiDocBaseUrl: 'http://127.0.0.1:8000/',

  // apiBaseUrl: 'http://10.246.75.73/bcas/api/',
  // apiDocBaseUrl: 'http://10.246.75.73/bcas/api/',
};
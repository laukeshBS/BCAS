import { Component } from '@angular/core';

@Component({
  selector: 'app-security-questions',
  standalone: true,
  imports: [],
  templateUrl: './security-questions.component.html',
  styleUrl: './security-questions.component.css'
})
export class SecurityQuestionsComponent {

}
